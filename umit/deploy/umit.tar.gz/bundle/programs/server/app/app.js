var require = meteorInstall({"imports":{"api":{"icpc.js":["meteor/meteor","meteor/mongo","meteor/check",function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////
//                                                                                      //
// imports/api/icpc.js                                                                  //
//                                                                                      //
//////////////////////////////////////////////////////////////////////////////////////////
                                                                                        //
module.export({                                                                         // 1
    IcpcCollection: function () {                                                       // 1
        return IcpcCollection;                                                          // 1
    },                                                                                  // 1
    GroupCollection: function () {                                                      // 1
        return GroupCollection;                                                         // 1
    }                                                                                   // 1
});                                                                                     // 1
var Meteor = void 0;                                                                    // 1
module.import('meteor/meteor', {                                                        // 1
    "Meteor": function (v) {                                                            // 1
        Meteor = v;                                                                     // 1
    }                                                                                   // 1
}, 0);                                                                                  // 1
var Mongo = void 0;                                                                     // 1
module.import('meteor/mongo', {                                                         // 1
    "Mongo": function (v) {                                                             // 1
        Mongo = v;                                                                      // 1
    }                                                                                   // 1
}, 1);                                                                                  // 1
var check = void 0,                                                                     // 1
    Match = void 0;                                                                     // 1
module.import('meteor/check', {                                                         // 1
    "check": function (v) {                                                             // 1
        check = v;                                                                      // 1
    },                                                                                  // 1
    "Match": function (v) {                                                             // 1
        Match = v;                                                                      // 1
    }                                                                                   // 1
}, 2);                                                                                  // 1
Meteor.methods({                                                                        // 11
    /*                                                                                  // 12
     * ICPC Groups                                                                      //
     * GroupCollection = db.icpc_groups                                                 //
     */'GroupCollection.get': function () {                                             //
        GroupCollection.find().fetch();                                                 // 17
    },                                                                                  // 18
    'GroupCollection.updateName': function (letter, name) {                             // 19
        return GroupCollection.update({                                                 // 20
            letter: letter                                                              // 20
        }, {                                                                            // 20
            $set: {                                                                     // 20
                name: name                                                              // 20
            }                                                                           // 20
        });                                                                             // 20
    },                                                                                  // 21
    'GroupCollection.updateNameByID': function (ID, name) {                             // 22
        return GroupCollection.update({                                                 // 23
            _id: ID                                                                     // 24
        }, {                                                                            // 24
            $set: {                                                                     // 25
                name: name                                                              // 25
            }                                                                           // 25
        });                                                                             // 25
    },                                                                                  // 27
    'GroupCollection.getGroupCount': function (letter) {                                // 28
        IcpcCollection.find({                                                           // 29
            letter: letter                                                              // 29
        }).count();                                                                     // 29
    },                                                                                  // 30
    'GroupCollection.updateGroupCount': function (letter) {                             // 31
        return GroupCollection.find().forEach(function (result) {                       // 32
            letter = result.letter;                                                     // 33
            GroupCollection.update({                                                    // 34
                _id: result._id                                                         // 35
            }, {                                                                        // 35
                $set: {                                                                 // 36
                    count: IcpcCollection.find({                                        // 37
                        letter: letter                                                  // 37
                    }).count()                                                          // 37
                }                                                                       // 36
            });                                                                         // 36
        });                                                                             // 40
    },                                                                                  // 41
    /*                                                                                  // 42
     * ICPC diseases                                                                    //
     * IcpcCollection = db.icpc_icpc                                                    //
     */'IcpcCollection.getCountByLetter': function (letter) {                           //
        IcpcCollection.find({                                                           // 47
            letter: letter                                                              // 47
        }).count();                                                                     // 47
    },                                                                                  // 48
    'IcpcCollection.getListByLetter': function (letter) {                               // 49
        check(letter, Match.OneOf(String));                                             // 50
        !isNaN(+letter) && (letter = +letter);                                          // 51
        return IcpcCollection.find({                                                    // 52
            letter: letter                                                              // 52
        }, {                                                                            // 52
            letter: 1,                                                                  // 52
            name: 1                                                                     // 52
        }).fetch();                                                                     // 52
    },                                                                                  // 53
    'IcpcCollection.getAllByLetter': function (letter) {                                // 54
        check(letter, Match.OneOf(String, Number));                                     // 55
        IcpcCollection.find({                                                           // 56
            letter: letter                                                              // 56
        }).fetch();                                                                     // 56
    },                                                                                  // 57
    'IcpcCollection.getByID': function (ID) {                                           // 58
        check(ID, String);                                                              // 59
        return IcpcCollection.find({                                                    // 60
            _id: ID                                                                     // 60
        }).fetch();                                                                     // 60
    },                                                                                  // 61
    'IcpcCollection.updateByID': function (ID, data) {                                  // 62
        check(ID, Match.OneOf(String));                                                 // 63
        return IcpcCollection.update(ID, {                                              // 64
            $set: {                                                                     // 64
                letter: data.letter,                                                    // 65
                consider: data.consider,                                                // 66
                criteria: data.criteria,                                                // 67
                exclusion: data.exclusion,                                              // 68
                inclusion: data.inclusion,                                              // 69
                name: data.name,                                                        // 70
                note: data.note                                                         // 71
            }                                                                           // 64
        });                                                                             // 64
    },                                                                                  // 73
    'IcpcCollection.insert': function (text) {                                          // 74
        check(text, String); // Make sure the user is logged in before inserting a task
                                                                                        //
        if (!Meteor.userId()) {                                                         // 78
            throw new Meteor.Error('not-authorized');                                   // 79
        }                                                                               // 80
                                                                                        //
        IcpcCollection.insert({                                                         // 82
            text: text,                                                                 // 83
            createdAt: new Date(),                                                      // 84
            owner: Meteor.userId(),                                                     // 85
            username: Meteor.user().username                                            // 86
        });                                                                             // 82
    },                                                                                  // 88
    'IcpcCollection.remove': function (ID) {                                            // 89
        check(ID, String);                                                              // 90
        IcpcCollection.remove(ID);                                                      // 92
    },                                                                                  // 93
    'IcpcCollection.setChecked': function (ID, setChecked) {                            // 94
        check(ID, String);                                                              // 95
        check(setChecked, Boolean);                                                     // 96
        IcpcCollection.update(ID, {                                                     // 98
            $set: {                                                                     // 98
                checked: setChecked                                                     // 98
            }                                                                           // 98
        });                                                                             // 98
    }                                                                                   // 99
}); // console.log('Mongo',new Mongo.Collection('icpc_icpc').find())                    // 11
                                                                                        //
var IcpcCollection = new Mongo.Collection('icpc_icpc');                                 // 104
var GroupCollection = new Mongo.Collection('icpc_groups');                              // 105
//////////////////////////////////////////////////////////////////////////////////////////

}],"tasks.js":["meteor/meteor","meteor/mongo","meteor/check",function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////
//                                                                                      //
// imports/api/tasks.js                                                                 //
//                                                                                      //
//////////////////////////////////////////////////////////////////////////////////////////
                                                                                        //
module.export({                                                                         // 1
    TaskCollection: function () {                                                       // 1
        return TaskCollection;                                                          // 1
    }                                                                                   // 1
});                                                                                     // 1
var Meteor = void 0;                                                                    // 1
module.import('meteor/meteor', {                                                        // 1
    "Meteor": function (v) {                                                            // 1
        Meteor = v;                                                                     // 1
    }                                                                                   // 1
}, 0);                                                                                  // 1
var Mongo = void 0;                                                                     // 1
module.import('meteor/mongo', {                                                         // 1
    "Mongo": function (v) {                                                             // 1
        Mongo = v;                                                                      // 1
    }                                                                                   // 1
}, 1);                                                                                  // 1
var check = void 0;                                                                     // 1
module.import('meteor/check', {                                                         // 1
    "check": function (v) {                                                             // 1
        check = v;                                                                      // 1
    }                                                                                   // 1
}, 2);                                                                                  // 1
Meteor.methods({                                                                        // 11
    'TaskCollection.insert': function (text) {                                          // 12
        check(text, String); // Make sure the user is logged in before inserting a task
                                                                                        //
        if (!Meteor.userId()) {                                                         // 16
            throw new Meteor.Error('not-authorized');                                   // 17
        }                                                                               // 18
                                                                                        //
        TaskCollection.insert({                                                         // 20
            text: text,                                                                 // 21
            createdAt: new Date(),                                                      // 22
            owner: Meteor.userId(),                                                     // 23
            username: Meteor.user().username                                            // 24
        });                                                                             // 20
    },                                                                                  // 26
    'TaskCollection.remove': function (taskId) {                                        // 27
        check(taskId, String);                                                          // 28
        TaskCollection.remove(taskId);                                                  // 30
    },                                                                                  // 31
    'TaskCollection.setChecked': function (taskId, setChecked) {                        // 32
        check(taskId, String);                                                          // 33
        check(setChecked, Boolean);                                                     // 34
        TaskCollection.update(taskId, {                                                 // 36
            $set: {                                                                     // 36
                checked: setChecked                                                     // 36
            }                                                                           // 36
        });                                                                             // 36
    }                                                                                   // 37
});                                                                                     // 11
var TaskCollection = new Mongo.Collection('tasks');                                     // 40
//////////////////////////////////////////////////////////////////////////////////////////

}]}},"server":{"social-config.js":function(){

//////////////////////////////////////////////////////////////////////////////////////////
//                                                                                      //
// server/social-config.js                                                              //
//                                                                                      //
//////////////////////////////////////////////////////////////////////////////////////////
                                                                                        //
/**                                                                                     // 1
 * Created by WebStorm.                                                                 //
 * User: Anton Kosiak                                                                   //
 * Date: 3/19/17                                                                        //
 * Time: 09:56                                                                          //
 */ServiceConfiguration.configurations.remove({                                         //
    service: 'facebook'                                                                 // 8
});                                                                                     // 7
ServiceConfiguration.configurations.insert({                                            // 11
    service: 'facebook',                                                                // 12
    appId: '341563082906242',                                                           // 13
    secret: 'bc3cc9e81bf7dc29eeacb9c24c2abbe2'                                          // 14
});                                                                                     // 11
//////////////////////////////////////////////////////////////////////////////////////////

},"main.js":["meteor/meteor","../imports/api/tasks.js","../imports/api/icpc.js","react",function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////
//                                                                                      //
// server/main.js                                                                       //
//                                                                                      //
//////////////////////////////////////////////////////////////////////////////////////////
                                                                                        //
var Meteor = void 0;                                                                    // 1
module.import('meteor/meteor', {                                                        // 1
    "Meteor": function (v) {                                                            // 1
        Meteor = v;                                                                     // 1
    }                                                                                   // 1
}, 0);                                                                                  // 1
module.import('../imports/api/tasks.js');                                               // 1
module.import('../imports/api/icpc.js');                                                // 1
var React = void 0;                                                                     // 1
module.import('react', {                                                                // 1
    "default": function (v) {                                                           // 1
        React = v;                                                                      // 1
    }                                                                                   // 1
}, 3);                                                                                  // 1
// import ReactDOMServer from 'react-dom/server';                                       // 6
// import { render } from 'react-dom';                                                  // 7
// import { Router, Route, IndexRoute, browserHistory } from 'react-router';            // 8
// import { StaticRouter } from 'react-router-dom';                                     // 9
// import { StaticRouter as Router, Route} from 'react-router-dom';                     // 10
// import App from '../imports/ui/App';                                                 // 11
// import '../imports/routes';                                                          // 13
// import { createServer } from 'http';                                                 // 15
// createServer((req, res) => {                                                         // 17
//                                                                                      // 18
//     // This context object contains the results of the render                        // 19
//     const context = {}                                                               // 20
//                                                                                      // 21
//     const html = ReactDOMServer.renderToString(                                      // 22
//         <StaticRouter location={req.url} context={context}>                          // 23
//             <App/>                                                                   // 24
//         </StaticRouter>                                                              // 25
//     )                                                                                // 26
//                                                                                      // 27
//     // context.url will contain the URL to redirect to if a <Redirect> was used      // 28
//     if (context.url) {                                                               // 29
//         res.writeHead(302, {                                                         // 30
//             Location: context.url                                                    // 31
//         })                                                                           // 32
//         res.end()                                                                    // 33
//     } else {                                                                         // 34
//         res.write(html)                                                              // 35
//         res.end()                                                                    // 36
//     }                                                                                // 37
// }).listen(4000)                                                                      // 38
// import fs from 'fs';                                                                 // 40
// let html = fs.readFile('/client/main.js', (err, data) => {                           // 41
//     if (err) throw err;                                                              // 42
//     console.log(data);                                                               // 43
// });                                                                                  // 44
// fs.readdir('./', (err, files) => {                                                   // 46
//     if (err) throw err;                                                              // 47
//     console.log(files);                                                              // 48
// });                                                                                  // 49
// import '../imports/routes';                                                          // 51
console.log(Meteor.isServer);                                                           // 53
Meteor.startup(function () {                                                            // 54
    // code to run on server at startup                                                 // 55
    console.info('Server is running good'); // const context = {}                       // 56
    /*const html = ReactDOMServer.renderToString(                                       // 59
        <StaticRouter                                                                   //
            location={'/'}                                                              //
            context={context}                                                           //
        >                                                                               //
            <div >Hello</div>                                                           //
            {/!*<App/>*!/}                                                              //
        </StaticRouter>                                                                 //
    )*/ // if (context.url) {                                                           //
    //     res.writeHead(301, {                                                         // 70
    //         Location: context.url                                                    // 71
    //     })                                                                           // 72
    //     res.end()                                                                    // 73
    // } else {                                                                         // 74
    // res.write(`                                                                      // 75
    //   <!doctype html>                                                                // 76
    //   <div id="app">${html}</div>                                                    // 77
    //`)                                                                                // 78
    //     res.end()                                                                    // 79
    // }                                                                                // 80
    // render(<App/>,this)                                                              // 81
    // console.log(arguments)                                                           // 82
    // return html;                                                                     // 83
    // return '<!doctype html>';                                                        // 84
    // render(                                                                          // 86
    //     <StaticRouter location={'/'} context={{}}>                                   // 87
    //         <App/>                                                                   // 88
    //     </StaticRouter>,                                                             // 89
    //     // <Router history={browserHistory} >                                        // 90
    //     //     <Route path="/" component={App} />                                    // 91
    //     // </Router>,                                                                // 92
    //     document.getElementById('render-target')                                     // 93
    // );                                                                               // 94
    //                                                                                  // 95
    /*render(                                                                           // 96
        <StaticRouter                                                                   //
            basename={'/'}                                                              //
            forceRefresh={false}                                                        //
            //getUserConfirmation={optionalFunc}                                        //
            //keyLength={optionalNumber}                                                //
        >                                                                               //
            <App/>                                                                      //
        </StaticRouter>,                                                                //
        // <Router history={browserHistory} >                                           //
        //     <Route path="/" component={App} />                                       //
        // </Router>,                                                                   //
        document.getElementById('render-target')                                        //
    );*/                                                                                //
});                                                                                     // 110
//////////////////////////////////////////////////////////////////////////////////////////

}]}},{"extensions":[".js",".json"]});
require("./server/social-config.js");
require("./server/main.js");
//# sourceMappingURL=app.js.map
